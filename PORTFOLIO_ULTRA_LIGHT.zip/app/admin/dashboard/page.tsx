"use client"

import { motion, AnimatePresence } from 'framer-motion'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { 
  LayoutDashboard, 
  FolderOpen, 
  Settings, 
  User, 
  Image, 
  FileText, 
  Link2, 
  LogOut,
  Plus,
  Edit3,
  Trash2,
  Save,
  X,
  Menu,
  ChevronRight,
  Bell,
  Search
} from 'lucide-react'

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', id: 'dashboard' },
  { icon: User, label: 'About', id: 'about' },
  { icon: FolderOpen, label: 'Portfolio', id: 'portfolio' },
  { icon: FileText, label: 'Services', id: 'services' },
  { icon: Link2, label: 'Social Links', id: 'social' },
  { icon: Image, label: 'Media', id: 'media' },
  { icon: Settings, label: 'Settings', id: 'settings' },
]

interface Project {
  id: string
  title: string
  category: string
  description: string
  image: string
  tags: string[]
}

interface SocialLink {
  id: string
  platform: string
  url: string
  icon: string
}

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [activeSection, setActiveSection] = useState('dashboard')
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Mock data for editing
  const [aboutData, setAboutData] = useState({
    name: 'Sk Taufique Hossain',
    title: 'Tech Entrepreneur & Creative Developer',
    bio: 'A passionate developer and AI innovator focused on building futuristic digital experiences.',
    email: 'contact@taufique.dev',
    phone: '+880 1234 567890',
    location: 'Bangladesh'
  })

  const [projects, setProjects] = useState<Project[]>([
    { id: '1', title: 'AI Trading Bot', category: 'AI', description: 'Automated trading system', image: '/project1.jpg', tags: ['Python', 'AI', 'Trading'] },
    { id: '2', title: 'E-Commerce Platform', category: 'Web', description: 'Full-stack e-commerce', image: '/project2.jpg', tags: ['Next.js', 'Stripe'] },
    { id: '3', title: 'Mobile Banking App', category: 'App', description: 'Fintech mobile app', image: '/project3.jpg', tags: ['React Native', 'Finance'] },
  ])

  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([
    { id: '1', platform: 'Instagram', url: 'https://instagram.com/taufique', icon: 'instagram' },
    { id: '2', platform: 'YouTube', url: 'https://youtube.com/@taufique', icon: 'youtube' },
    { id: '3', platform: 'GitHub', url: 'https://github.com/taufique', icon: 'github' },
    { id: '4', platform: 'LinkedIn', url: 'https://linkedin.com/in/taufique', icon: 'linkedin' },
    { id: '5', platform: 'Discord', url: 'https://discord.gg/taufique', icon: 'discord' },
    { id: '6', platform: 'Telegram', url: 'https://t.me/taufique', icon: 'telegram' },
  ])

  const [editingProject, setEditingProject] = useState<Project | null>(null)
  const [showProjectModal, setShowProjectModal] = useState(false)

  useEffect(() => {
    const isAuth = localStorage.getItem('admin_authenticated')
    const session = localStorage.getItem('admin_session')
    
    if (isAuth === 'true' && session) {
      // Check if session is less than 24 hours old
      const sessionTime = parseInt(session)
      const now = Date.now()
      if (now - sessionTime < 24 * 60 * 60 * 1000) {
        setIsAuthenticated(true)
      } else {
        localStorage.removeItem('admin_authenticated')
        localStorage.removeItem('admin_session')
        router.push('/admin')
      }
    } else {
      router.push('/admin')
    }
    setIsLoading(false)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('admin_authenticated')
    localStorage.removeItem('admin_session')
    router.push('/admin')
  }

  const saveAboutData = () => {
    // In production, save to database
    alert('About section saved successfully!')
  }

  const saveProject = (project: Project) => {
    if (editingProject) {
      setProjects(projects.map(p => p.id === project.id ? project : p))
    } else {
      setProjects([...projects, { ...project, id: Date.now().toString() }])
    }
    setShowProjectModal(false)
    setEditingProject(null)
  }

  const deleteProject = (id: string) => {
    if (confirm('Are you sure you want to delete this project?')) {
      setProjects(projects.filter(p => p.id !== id))
    }
  }

  const updateSocialLink = (id: string, url: string) => {
    setSocialLinks(socialLinks.map(link => 
      link.id === id ? { ...link, url } : link
    ))
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-accent/30 border-t-accent rounded-full animate-spin" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: isSidebarOpen ? 0 : -300 }}
        className={`fixed lg:relative z-40 h-screen w-72 bg-card border-r border-border/50 flex flex-col ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0 lg:w-20'
        } transition-all duration-300`}
      >
        {/* Logo */}
        <div className="p-6 border-b border-border/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center">
              <span className="text-lg font-bold text-white">T</span>
            </div>
            {isSidebarOpen && (
              <div>
                <h2 className="font-semibold text-foreground">Admin Panel</h2>
                <p className="text-xs text-muted-foreground">Sk Taufique Hossain</p>
              </div>
            )}
          </div>
        </div>

        {/* Menu */}
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            const isActive = activeSection === item.id
            return (
              <motion.button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                whileHover={{ x: 4 }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-accent text-white' 
                    : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {isSidebarOpen && <span className="font-medium">{item.label}</span>}
                {isSidebarOpen && isActive && <ChevronRight className="w-4 h-4 ml-auto" />}
              </motion.button>
            )
          })}
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-border/50">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-all"
          >
            <LogOut className="w-5 h-5" />
            {isSidebarOpen && <span className="font-medium">Logout</span>}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Top Bar */}
        <header className="h-16 border-b border-border/50 bg-card/50 backdrop-blur-xl flex items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-lg hover:bg-secondary transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-lg font-semibold text-foreground capitalize">
              {activeSection}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search..."
                className="pl-10 pr-4 py-2 bg-secondary/50 border border-border/50 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-accent/50"
              />
            </div>
            <button className="relative p-2 rounded-lg hover:bg-secondary transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-accent rounded-full" />
            </button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center text-white text-sm font-medium">
              T
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-6 overflow-auto">
          <AnimatePresence mode="wait">
            {/* Dashboard */}
            {activeSection === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Total Projects', value: projects.length, color: 'from-blue-500 to-blue-600' },
                    { label: 'Social Links', value: socialLinks.length, color: 'from-purple-500 to-purple-600' },
                    { label: 'Page Views', value: '12.5K', color: 'from-green-500 to-green-600' },
                    { label: 'Inquiries', value: '45', color: 'from-orange-500 to-orange-600' },
                  ].map((stat, i) => (
                    <motion.div
                      key={stat.label}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="bg-card rounded-2xl border border-border/50 p-6"
                    >
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <p className="text-3xl font-bold mt-2 bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent">
                        {stat.value}
                      </p>
                    </motion.div>
                  ))}
                </div>

                <div className="bg-card rounded-2xl border border-border/50 p-6">
                  <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    {[
                      { label: 'Add New Project', icon: Plus, action: () => { setEditingProject(null); setShowProjectModal(true); } },
                      { label: 'Edit About Section', icon: Edit3, action: () => setActiveSection('about') },
                      { label: 'View Portfolio', icon: FolderOpen, action: () => window.open('/', '_blank') },
                    ].map((action) => {
                      const Icon = action.icon
                      return (
                        <button
                          key={action.label}
                          onClick={action.action}
                          className="flex items-center gap-3 p-4 bg-secondary/50 rounded-xl hover:bg-secondary transition-colors"
                        >
                          <Icon className="w-5 h-5 text-accent" />
                          <span className="font-medium">{action.label}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>
              </motion.div>
            )}

            {/* About Section Editor */}
            {activeSection === 'about' && (
              <motion.div
                key="about"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="max-w-2xl space-y-6"
              >
                <div className="bg-card rounded-2xl border border-border/50 p-6">
                  <h3 className="text-lg font-semibold mb-6">Edit About Section</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-foreground">Full Name</label>
                      <input
                        type="text"
                        value={aboutData.name}
                        onChange={(e) => setAboutData({ ...aboutData, name: e.target.value })}
                        className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground">Title</label>
                      <input
                        type="text"
                        value={aboutData.title}
                        onChange={(e) => setAboutData({ ...aboutData, title: e.target.value })}
                        className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground">Bio</label>
                      <textarea
                        value={aboutData.bio}
                        onChange={(e) => setAboutData({ ...aboutData, bio: e.target.value })}
                        rows={4}
                        className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50 resize-none"
                      />
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-foreground">Email</label>
                        <input
                          type="email"
                          value={aboutData.email}
                          onChange={(e) => setAboutData({ ...aboutData, email: e.target.value })}
                          className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-foreground">Phone</label>
                        <input
                          type="tel"
                          value={aboutData.phone}
                          onChange={(e) => setAboutData({ ...aboutData, phone: e.target.value })}
                          className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground">Location</label>
                      <input
                        type="text"
                        value={aboutData.location}
                        onChange={(e) => setAboutData({ ...aboutData, location: e.target.value })}
                        className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                      />
                    </div>
                    <button
                      onClick={saveAboutData}
                      className="flex items-center gap-2 px-6 py-3 bg-accent text-white rounded-xl font-medium hover:bg-accent/90 transition-colors"
                    >
                      <Save className="w-4 h-4" />
                      Save Changes
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Portfolio Editor */}
            {activeSection === 'portfolio' && (
              <motion.div
                key="portfolio"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Manage Projects</h3>
                  <button
                    onClick={() => { setEditingProject(null); setShowProjectModal(true); }}
                    className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-xl font-medium hover:bg-accent/90 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    Add Project
                  </button>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {projects.map((project) => (
                    <motion.div
                      key={project.id}
                      layout
                      className="bg-card rounded-2xl border border-border/50 overflow-hidden"
                    >
                      <div className="aspect-video bg-secondary flex items-center justify-center">
                        <Image className="w-12 h-12 text-muted-foreground" />
                      </div>
                      <div className="p-4">
                        <h4 className="font-semibold">{project.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{project.category}</p>
                        <div className="flex gap-2 mt-4">
                          <button
                            onClick={() => { setEditingProject(project); setShowProjectModal(true); }}
                            className="flex-1 flex items-center justify-center gap-2 py-2 bg-secondary rounded-lg hover:bg-secondary/80 transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                            Edit
                          </button>
                          <button
                            onClick={() => deleteProject(project.id)}
                            className="flex items-center justify-center px-3 py-2 bg-destructive/10 text-destructive rounded-lg hover:bg-destructive/20 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Social Links Editor */}
            {activeSection === 'social' && (
              <motion.div
                key="social"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="max-w-2xl space-y-6"
              >
                <div className="bg-card rounded-2xl border border-border/50 p-6">
                  <h3 className="text-lg font-semibold mb-6">Edit Social Links</h3>
                  <div className="space-y-4">
                    {socialLinks.map((link) => (
                      <div key={link.id} className="flex items-center gap-4">
                        <div className="w-24 text-sm font-medium text-foreground">
                          {link.platform}
                        </div>
                        <input
                          type="url"
                          value={link.url}
                          onChange={(e) => updateSocialLink(link.id, e.target.value)}
                          className="flex-1 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50 text-sm"
                          placeholder={`Enter ${link.platform} URL`}
                        />
                      </div>
                    ))}
                    <button
                      onClick={() => alert('Social links saved!')}
                      className="flex items-center gap-2 px-6 py-3 bg-accent text-white rounded-xl font-medium hover:bg-accent/90 transition-colors mt-6"
                    >
                      <Save className="w-4 h-4" />
                      Save All Links
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Services, Media, Settings - Placeholder */}
            {['services', 'media', 'settings'].includes(activeSection) && (
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex flex-col items-center justify-center h-64 text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center mb-4">
                  <Settings className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold capitalize">{activeSection} Editor</h3>
                <p className="text-muted-foreground mt-2">
                  This section is being developed. Coming soon!
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Project Modal */}
      <AnimatePresence>
        {showProjectModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6"
            onClick={() => setShowProjectModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-card rounded-2xl border border-border/50 p-6 w-full max-w-lg"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold">
                  {editingProject ? 'Edit Project' : 'Add New Project'}
                </h3>
                <button
                  onClick={() => setShowProjectModal(false)}
                  className="p-2 hover:bg-secondary rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  const formData = new FormData(e.currentTarget)
                  saveProject({
                    id: editingProject?.id || '',
                    title: formData.get('title') as string,
                    category: formData.get('category') as string,
                    description: formData.get('description') as string,
                    image: '/project.jpg',
                    tags: (formData.get('tags') as string).split(',').map(t => t.trim()),
                  })
                }}
                className="space-y-4"
              >
                <div>
                  <label className="text-sm font-medium">Project Title</label>
                  <input
                    name="title"
                    defaultValue={editingProject?.title}
                    className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <select
                    name="category"
                    defaultValue={editingProject?.category}
                    className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                    required
                  >
                    <option value="Web">Web Development</option>
                    <option value="App">App Development</option>
                    <option value="AI">AI / Automation</option>
                    <option value="Design">UI/UX Design</option>
                    <option value="Branding">Branding</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium">Description</label>
                  <textarea
                    name="description"
                    defaultValue={editingProject?.description}
                    rows={3}
                    className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50 resize-none"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Tags (comma separated)</label>
                  <input
                    name="tags"
                    defaultValue={editingProject?.tags.join(', ')}
                    className="w-full mt-1.5 px-4 py-3 bg-secondary/50 border border-border/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50"
                    placeholder="React, TypeScript, AI"
                    required
                  />
                </div>
                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowProjectModal(false)}
                    className="flex-1 py-3 bg-secondary rounded-xl font-medium hover:bg-secondary/80 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-accent text-white rounded-xl font-medium hover:bg-accent/90 transition-colors"
                  >
                    {editingProject ? 'Update' : 'Create'} Project
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
